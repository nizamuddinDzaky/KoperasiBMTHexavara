
<div class="modal fade" id="transferRekModal" role="dialog" aria-labelledby="addOrgLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="card card-wizard" id="wizardCardTrans">
            <form id="wizardFormTrans" method="POST" <?php if(Auth::user()->tipe=="admin"): ?> action="<?php echo e(route('transfer')); ?>" <?php else: ?> action="<?php echo e(route('teller.transfer')); ?>" <?php endif; ?> enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="header text-center">
                    <h3 class="title">Transfer Antar Rekening</h3>
                    <p class="category">BMT MANDIRI UKHUWAH PERSADA</p>
                </div>

                <div class="content">
                    <ul class="nav">
                        <li><a href="#tab1TabTrs" data-toggle="tab">Data Rekening</a></li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane" id="tab1TabTrs">
                            <h5 class="text-center">Pastikan kembali data yang anda masukkan sudah benar!</h5>
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label for="id_" class="control-label">Transfer dari Rekening <star>*</star></label>
                                        <select class="form-control select2" id="idRekD" name="dari" style="width: 100%;" required>
                                            <option class="bs-title-option" selected disabled value="">-Pilih Rekening BMT-</option>
                                            <?php $__currentLoopData = $dropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($rekening->id); ?>">[<?php echo e($rekening->id_rekening); ?>] <?php echo e($rekening->nama_rekening); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label for="id_" class="control-label">Transfer ke Rekening <star>*</star></label>
                                        <select class="form-control select2" id="idRekT" name="untuk" style="width: 100%;" required>
                                            <option class="bs-title-option" selected disabled value="">-Pilih Rekening BMT-</option>
                                            <?php $__currentLoopData = $dropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($rekening->id); ?>">[<?php echo e($rekening->id_rekening); ?>] <?php echo e($rekening->nama_rekening); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label class="control-label">Jumlah Uang <star>*</star></label>
                                        <div class="input-group">
                                            <span class="input-group-addon">Rp</span>
                                            <input type="text" class="currency form-control text-right" id="jumlah" name="jumlah" required="true">
                                            <span class="input-group-addon">.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="footer">
                    <button type="submit" class="btn btn-info btn-fill btn-wd btn-finish pull-right">Transfer </button>
                    <button type="button" class="btn btn-secondary pull-right" data-dismiss="modal" style="margin-right: 0.5em">Batal</button>
                    <div class="clearfix"></div>
                </div>
            </form>

        </div>
    </div>
</div>


<div class="modal fade" id="jurnalLainRekModal" role="dialog" aria-labelledby="addOrgLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="card card-wizard" id="wizardCardJ">
            <form id="wizardFormJ" method="POST" <?php if(Auth::user()->tipe=="admin"): ?> action="<?php echo e(route('jurnal_lain')); ?>" <?php else: ?> action="<?php echo e(route('teller.jurnal_lain')); ?>" <?php endif; ?>  enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="header text-center">
                    <h3 class="title">Pengeluaran/Pemasukan</h3>
                    <p class="category">BMT MANDIRI UKHUWAH PERSADA</p>
                </div>

                <div class="content">
                    <ul class="nav">
                        <li><a href="#tab1TabJ" data-toggle="tab">Data Jurnal</a></li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane" id="tab1TabJ">
                            <h5 class="text-center">Pastikan kembali data yang anda masukkan sudah benar!</h5>

                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label for="id_" class="control-label">Transfer ke Rekening <star>*</star></label>
                                        <select class="form-control select2" id="idRekJ" name="untuk" style="width: 100%;" required>
                                            <option class="bs-title-option" selected disabled value="">-Pilih Rekening BMT-</option>
                                            <?php $__currentLoopData = $dropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($rekening->id); ?>">[<?php echo e($rekening->id_rekening); ?>] <?php echo e($rekening->nama_rekening); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label for="id_" class="control-label">Tipe Transaksi <star>*</star></label>
                                        <select class="form-control select2"  name="tipe" style="width: 100%;" required>
                                            <option class="bs-title-option" selected disabled value="">-Pilih Transaksi-</option>
                                            <option value="1">Pemasukkan</option>
                                            <option value="0">Pengeluaran</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label for="id_" class="control-label">Keterangan<star>*</star></label>
                                        <input type="text" class="form-control"  name="keterangan" required="true">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label class="control-label">Jumlah Uang <star>*</star></label>
                                        <div class="input-group">
                                            <span class="input-group-addon">Rp</span>
                                            <input type="text" class="currency form-control text-right" id="jumlah" name="jumlah" required="true">
                                            <span class="input-group-addon">.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="footer">
                    <button type="submit" class="btn btn-info btn-fill btn-wd btn-finish pull-right">Transfer Pengeluaran/Pemasukan </button>
                    <button type="button" class="btn btn-secondary pull-right" data-dismiss="modal" style="margin-right: 0.5em">Batal</button>
                    <div class="clearfix"></div>
                </div>
            </form>

        </div>
    </div>
</div>


<div class="modal fade" id="editSaldoModal" role="dialog" aria-labelledby="addOrgLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="card card-wizard" id="wizardCardS">
            <form id="wizardFormS" method="POST" <?php if(Auth::user()->tipe=="admin"): ?> action="<?php echo e(route('edit.saldo')); ?>" <?php else: ?>  action="<?php echo e(route('teller.edit.saldo')); ?>" <?php endif; ?> enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="header text-center">
                    <h3 class="title">Edit Saldo Rekening</h3>
                    <p class="category">BMT MANDIRI UKHUWAH PERSADA</p>
                </div>

                <div class="content">
                    <ul class="nav">
                        <li><a href="#tab1" data-toggle="tab">Data Rekening</a></li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane" id="tab1">
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label for="id_" class="control-label">Nama Rekening <star>*</star></label>
                                        <select class="form-control select2" id="idRekS" disabled name="dari" style="width: 100%;" required>
                                            <option class="bs-title-option" selected disabled value="">-Pilih Rekening Tabungan Anda-</option>
                                            <?php $__currentLoopData = $dropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($rekening->id); ?>">[<?php echo e($rekening->id_rekening); ?>] <?php echo e($rekening->nama_rekening); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" id="id_bmt" name="id_">
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label class="control-label">Saldo Rekening <star>*</star></label>
                                        <div class="input-group">
                                            <span class="input-group-addon">Rp</span>
                                            <input type="text" class="currency form-control text-right" id="saldo" name="jumlah" required="true">
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="footer">
                    <button type="submit" class="btn btn-info btn-fill btn-wd btn-finish pull-right">Edit Saldo </button>
                    <button type="button" class="btn btn-secondary pull-right" data-dismiss="modal" style="margin-right: 0.5em">Batal</button>
                    <div class="clearfix"></div>
                </div>
            </form>

        </div>
    </div>
</div>



<div class="modal fade" id="wapokRekModal" role="dialog" aria-labelledby="addOrgLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="card card-wizard" id="wizardCardWP">
            <form id="wizardFormWP" method="POST" <?php if(Auth::user()->tipe=="admin"): ?> action="<?php echo e(route('upgrade_simp')); ?>" <?php else: ?> action="<?php echo e(route('teller.upgrade_simp')); ?>" <?php endif; ?> enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="header text-center">
                    <h3 class="title">Updgrade Simpanan Wajib Pokok</h3>
                    <p class="category">BMT MANDIRI UKHUWAH PERSADA</p>
                </div>

                <div class="content">
                    <ul class="nav">
                        <li><a href="#tab1TabWP" data-toggle="tab">Data Simpanan Wajib Pokok</a></li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane" id="tab1TabWP">
                            <h5 class="text-center">Pastikan kembali data yang anda masukkan sudah benar!</h5>

                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label for="id_" class="control-label">Jenis Simpanan <star>*</star></label>
                                        <select class="form-control select2"  name="wapok" style="width: 100%;" required>
                                            <option class="bs-title-option" selected disabled value="">-Pilih Jenis-</option>
                                            <option value="1">Simpanan Wajib</option>
                                            <option value="0">Simpanan Pokok</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                                
                                    
                                        
                                        
                                            
                                            
                                            
                                        
                                    
                                
                            
                            
                                
                                    
                                        
                                        
                                        
                                            
                                            
                                                
                                            
                                        
                                    
                                
                                
                                
                            
                            
                                
                                    
                                        
                                        
                                            
                                            
                                            
                                        
                                    
                                
                            
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label for="id_" class="control-label">Keterangan<star>*</star></label>
                                        <input type="text" class="form-control"  name="keterangan" required="true">
                                    </div>
                                </div>
                            </div>
                            <div class="row" id="saldoRek">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label class="control-label">Saldo Rekening <star>*</star></label>
                                        <div class="input-group">
                                            <span class="input-group-addon">Rp</span>
                                            <input type="text" class="currency form-control text-right" id="j_rek" disabled>
                                            <span class="input-group-addon">.00</span>
                                        </div>
                                        <span id="validate-status"class="help-block text-danger"><star>*</star></span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-5 col-md-offset-1">
                                    <div class="form-group">
                                        <label class="control-label">Jumlah Nasabah <star>*</star></label>
                                        <input type="text" class="form-control text-right" id="nas_" value="<?php echo e($nasabah); ?>"  disabled>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label class="control-label">Total<star>*</star></label>
                                        <div class="input-group">
                                            <span class="input-group-addon">Rp</span>
                                            <input type="text" class="currency form-control text-right" id="tot_nas" disabled>
                                            <span class="input-group-addon">.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <div class="form-group">
                                        <label class="control-label">Jumlah Upgrade per Nasabah <star>*</star></label>
                                        <div class="input-group">
                                            <span class="input-group-addon">Rp</span>
                                            <input type="text" class="currency form-control text-right" id="j_upgrade" name="jumlah" required="true">
                                            <span class="input-group-addon">.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="footer">
                    <button type="submit" id="submit-button" class="btn btn-info btn-fill btn-wd btn-finish pull-right">Upgrade Simpanan </button>
                    <button type="button" class="btn btn-secondary pull-right" data-dismiss="modal" style="margin-right: 0.5em">Batal</button>
                    <div class="clearfix"></div>
                </div>
            </form>

        </div>
    </div>
</div>
