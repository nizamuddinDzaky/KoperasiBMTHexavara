<?php $__env->startSection('side-navbar'); ?>
	<?php echo $__env->make('layouts.side_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-navbar'); ?>
	<?php echo $__env->make('layouts.top_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="container-fluid">
			<div class="row">

				<div class="col-md-8">
					<span class="help-block text-danger"><?php echo e($errors->first('file')); ?></span>
					
					
					
					
					
					<?php if($status->status == 1): ?>
						<div class="alert alert-success text-center">
							<span>Sementara ini Anda tidak dapat mengakses menu Anggota! Silahkan Menunggu <b>Konfirmasi Admin</b> terlebih dahulu!</span>
						</div>
					<?php endif; ?>
					<div class="card card-wizard" id="wizardCard">
						<form id="wizardForm" method="POST" action="<?php echo e(route('addidentitas')); ?>" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<div class="header text-center">
							<h3 class="title">Identitas Anggota</h3>
							<p class="category">Isi data diri anda sebelum memilih menu berikutnya</p>
						</div>

						<div class="content">
							<ul class="nav">
								<li><a href="#tab1" data-toggle="tab">Data Diri</a></li>
								<li><a href="#tab2" data-toggle="tab">Pendidikan dan Pekerjaan</a></li>
								<li><a href="#tab3" data-toggle="tab">Tanggungan Keluarga</a></li>
							</ul>

							<div class="tab-content">
								<div class="tab-pane" id="tab1">
									<h5 class="text-center">Pastikan data yang anda masukkan sesuai dengan data diri anda</h5>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">No KTP</label>
												<input class="form-control"
													   disabled
													   type="text"
													   name="no_ktp"
													   disabled
													   value="<?php echo e($status->no_ktp); ?>"
												/>
											</div>
										</div>
										<div class="col-md-5">
											<div class="form-group">
												<label class="control-label">NIK/KSK</label>
												<input class="form-control"
													   type="text"
													   name="nik"
													   disabled
													   value="<?php echo e(isset(json_decode($status->detail,true)['nik']) ? (json_decode($status->detail,true)['nik']):""); ?>"
												/>
											</div>
										</div>

									</div>
									<div class="row">
										<div class="col-md-10 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Nama Lengkap</label>
												<input class="form-control"
													   type="text"
													   name="nama"
													   value="<?php echo e($status->nama); ?>"
													   disabled
												/>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Telepon/HP</label>
												<input class="form-control"
													   type="text"
													   name="telepon"
													   value="<?php echo e(isset(json_decode($status->detail,true)['telepon'])?json_decode($status->detail,true)['telepon']:""); ?>"
													   disabled
												/>
											</div>
										</div>
										
										<div class="col-md-5">
											<div class="form-group">
												<label class="control-label">Jenis Kelamin</label>
												<select id name="jenisKel" class="form-control" disabled selected="<?php echo e(isset(json_decode($status->detail,true)['jenis_kelamin'])?json_decode($status->detail,true)['jenis_kelamin']:0); ?>">
													<option value="0" disabled="">- pilih -</option>
													<option value="L" <?php if(isset(json_decode($status->detail,true)['jenis_kelamin'])?json_decode($status->detail,true)['jenis_kelamin']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['jenis_kelamin'] == "L" ? ' selected="selected"' : ''); ?><?php endif; ?>>Laki-laki</option>
													<option value="P" <?php if(isset(json_decode($status->detail,true)['jenis_kelamin'])?json_decode($status->detail,true)['jenis_kelamin']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['jenis_kelamin'] == "P" ? ' selected="selected"' : ''); ?><?php endif; ?>>Perempuan</option>
												</select>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Tempat lahir</label>
												<input class="form-control"
													   type="text"
													   name="tempat"
													   value="<?php echo e(isset(json_decode($status->detail,true)['tempat_lahir'])?json_decode($status->detail,true)['tempat_lahir']:""); ?>"
													   disabled
												/>
											</div>
										</div>
										<div class="col-md-5">
											<div class="form-group">
												<label class="control-label">Tanggal lahir</label>
												<input class="form-control datepicker"
													   type="text"
													   id = "tLahir"
													   name="tglLahir"
													   disabled
												/>
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-md-10 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Alamat (sesuai KTP)<star>*</star></label>
												<input class="form-control"
													   type="text"
													   name="alamat"
													   value="<?php echo e(isset(json_decode($status->detail,true)['alamat_ktp'])?json_decode($status->detail,true)['alamat_ktp']:""); ?>"
													   disabled
												/>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-10 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Alamat Domisili<star>*</star></label>
												<input class="form-control"
													   type="text"
													   name="domisili"
													   value="<?php echo e($status->alamat); ?>"
													   disabled
												/>
											</div>
										</div>
									</div>

								</div>
								<div class="tab-pane" id="tab2">
									<h5 class="text-center">Pastikan data yang anda masukkan sesuai dengan data diri anda</h5>
									<div class="row">
										<div class="col-md-10 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Pendidikan Terakhir<star>*</star></label>
												<select name="pendidikan" class="form-control" disabled
														selected="<?php echo e(isset(json_decode($status->detail,true)['pendidikan'])?json_decode($status->detail,true)['pendidikan']:""); ?> required >
												>
												<option disabled="true">- pilih -</option>
												<option value="0" <?php if(isset(json_decode($status->detail,true)['pendidikan'])?json_decode($status->detail,true)['pendidikan']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['pendidikan'] == "0" ? ' selected="selected"' : ''); ?> <?php endif; ?>>Tidak Sekolah</option>
												<option value="SD" <?php if(isset(json_decode($status->detail,true)['pendidikan'])?json_decode($status->detail,true)['pendidikan']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['pendidikan'] == "SD" ? ' selected="selected"' : ''); ?><?php endif; ?> >SD/MI</option>
												<option value="SMP" <?php if(isset(json_decode($status->detail,true)['pendidikan'])?json_decode($status->detail,true)['pendidikan']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['pendidikan'] == "SMP" ? ' selected="selected"' : ''); ?> <?php endif; ?>>SMP/SLTP/MTS</option>
												<option value="SMA" <?php if(isset(json_decode($status->detail,true)['pendidikan'])?json_decode($status->detail,true)['pendidikan']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['pendidikan'] == "SMA" ? ' selected="selected"' : ''); ?><?php endif; ?>>SMA/SMK/SLTA/MAN</option>
												<option value="D1" <?php if(isset(json_decode($status->detail,true)['pendidikan'])?json_decode($status->detail,true)['pendidikan']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['pendidikan'] == "D4" ? ' selected="selected"' : ''); ?><?php endif; ?>>D1/D3</option>
												<option value="S1" <?php if(isset(json_decode($status->detail,true)['pendidikan'])?json_decode($status->detail,true)['pendidikan']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['pendidikan'] == "S1" ? ' selected="selected"' : ''); ?><?php endif; ?>>S1/D4</option>
												<option value="S2" <?php if(isset(json_decode($status->detail,true)['pendidikan'])?json_decode($status->detail,true)['pendidikan']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['pendidikan'] == "S2" ? ' selected="selected"' : ''); ?><?php endif; ?>>S2/S3</option>
												</select>
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-md-10 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Pekerjaan<star>*</star></label>
												<input class="form-control"
													   value="<?php echo e(isset(json_decode($status->detail,true)['pekerjaan'])?json_decode($status->detail,true)['pekerjaan']:""); ?>"
													   type="text"
													   name="kerja"
													   disabled
												/>
												</div>
										</div>

									</div>
									<div class="row">
										<div class="col-md-10 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Pendapatan Bulanan<star>*</star></label>
												<div class="input-group">
												<span class="input-group-addon">Rp</span>
												<input class="currency form-control text-right"
													   value="<?php echo e(isset(json_decode($status->detail,true)['pendapatan'])?number_format(json_decode($status->detail,true)['pendapatan']):""); ?>"
													   type="text"
													   name="pendapatan"
													   disabled
												/>
												<span class="input-group-addon">.00</span>
												</div>
											</div>
										</div>

									</div>

									<div class="row">
										<div class="col-md-10 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Alamat Pekerjaan<star>*</star></label>
												<input class="form-control"
													   value="<?php echo e(isset(json_decode($status->detail,true)['alamat_kerja'])?json_decode($status->detail,true)['alamat_kerja']:""); ?>"
													   type="text"
													   name="alamatKer" disabled
												/>
											</div>
										</div>
									</div>

								</div>

								<div class="tab-pane" id="tab3">
									<h5 class="text-center">Pastikan data yang anda masukkan sesuai dengan data diri anda</h5>
									
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Status Pernikahan</label>
												<select name="status" class="form-control" disabled>
													<option disabled="">- pilih -</option>
													<option value="S" <?php if(isset(json_decode($status->detail,true)['status'])?json_decode($status->detail,true)['status']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['status'] == "S" ? ' selected="selected"' : ''); ?><?php endif; ?>>Single</option>
													<option value="M" <?php if(isset(json_decode($status->detail,true)['status'])?json_decode($status->detail,true)['status']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['status'] == "M" ? ' selected="selected"' : ''); ?><?php endif; ?>>Menikah</option>
												</select>

											</div>
										</div>
										<div class="col-md-5">
											<div class="form-group">
												<label class="control-label">Nama Suami/Istri/Wali</label>
												<input class="form-control"
													   type="text"
													   name="wali"
													   value="<?php echo e(isset(json_decode($status->detail,true)['nama_wali'])?json_decode($status->detail,true)['nama_wali']:""); ?>"
													   disabled
												/>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Nama Ayah</label>
												<input class="form-control"
													   type="text"
													   name="ayah"
													   value="<?php echo e(isset(json_decode($status->detail,true)['ayah'])?json_decode($status->detail,true)['ayah']:""); ?>"
													   disabled
												/>
											</div>
										</div>
										<div class="col-md-5">
											<div class="form-group">
												<label class="control-label">Nama Ibu</label>
												<input class="form-control"
													   type="text"
													   name="ibu"
													   value="<?php echo e(isset(json_decode($status->detail,true)['ibu'])?json_decode($status->detail,true)['ibu']:""); ?>"
													   disabled
												/>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Jumlah Suami/Istri</label>
												<input class="form-control"
													   type="number"
													   name="jsumis"
													   value="<?php echo e(isset(json_decode($status->detail,true)['jml_sumis'])?json_decode($status->detail,true)['jml_sumis']:""); ?>"
													   disabled
												/>
											</div>
										</div>
										<div class="col-md-5">
											<div class="form-group">
												<label class="control-label">Jumlah Anak</label>
												<input class="form-control"
													   type="number"
													   name="juman"
													   value="<?php echo e(isset(json_decode($status->detail,true)['jml_anak'])?json_decode($status->detail,true)['jml_anak']:""); ?>"
													   disabled
												/>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">
											<div class="form-group">
												<label class="control-label">Jumlah Orang Tua</label>
												<input class="form-control"
													   type="number"
													   name="jortu"
													   value="<?php echo e(isset(json_decode($status->detail,true)['jml_ortu'])?json_decode($status->detail,true)['jml_ortu']:""); ?>"
													   disabled
												/>
											</div>
										</div>
										<div class="col-md-5">
											<div class="form-group">
												<label class="control-label">Lain-lain</label>
												<input class="form-control"
													   type="number"
													   name="lain"
													   value="<?php echo e(isset(json_decode($status->detail,true)['lain'])?json_decode($status->detail,true)['lain']:""); ?>"
													   disabled
												/>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-5 col-md-offset-1 <?php echo e(!$errors->has('file') ?: 'has-error'); ?>">
											<div class="form-group">
													<span class=""> KTP
													</span><br><br>
												<div class="text-center">
													<img style="margin: auto;width:100px;height:auto" id="pic" src="<?php echo e(url('storage/public/file/'.json_decode($status->pathfile,true)['KTP'])); ?>"/>
												</div>
												
											</div>
										</div>
										<div class="col-md-5 <?php echo e(!$errors->has('file') ?: 'has-error'); ?>">
											<div class="form-group">
												
												<span class=""> KSK
													</span><br><br>
												<div class="text-center">
													<img style="margin: auto;width:100px;height:auto" id="pic2" src="<?php echo e(url('storage/public/file/'.json_decode($status->pathfile,true)['KSK'])); ?>"/>
												</div>
												<span class="help-block text-danger"><?php echo e($errors->first('fileksk')); ?></span>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-5 col-md-offset-1">

											<div class="form-group">
												
												<span class=""> Buku Nikah
													</span><br><br>
												<div class="text-center">
													<img style="margin: auto;width:100px;height:auto" id="pic3" src="<?php echo e(url('storage/public/file/'.json_decode($status->pathfile,true)['Nikah'])); ?>"/>
												</div>
												<span class="help-block text-danger"><?php echo e($errors->first('filenikah')); ?></span>
											</div>
										</div>
										<div class="col-md-5 <?php echo e(!$errors->has('file') ?: 'has-error'); ?>">
											<div class="form-group">
												<label class="control-label">Status Kepemilikan Rumah</label>
												<select name="rumah" class="form-control" disabled selected="<?php echo e(isset(json_decode($status->detail,true)['rumah'])?json_decode($status->detail,true)['rumah']:""); ?>" required>
													<option disabled="">- pilih -</option>
													<option value="HM"  <?php if(isset(json_decode($status->detail,true)['rumah'])?json_decode($status->detail,true)['rumah']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['rumah'] == "HM" ? ' selected="selected"' : ''); ?> <?php endif; ?>>Hak milik</option>
													<option value="KK" <?php if(isset(json_decode($status->detail,true)['rumah'])?json_decode($status->detail,true)['rumah']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['rumah'] == "KK" ? ' selected="selected"' : ''); ?><?php endif; ?>>Kontrak</option>
													<option value="KS" <?php if(isset(json_decode($status->detail,true)['rumah'])?json_decode($status->detail,true)['rumah']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['rumah'] == "KS" ? ' selected="selected"' : ''); ?><?php endif; ?>>Kos</option>
													<option value="MW" <?php if(isset(json_decode($status->detail,true)['rumah'])?json_decode($status->detail,true)['rumah']:"0"!="0"): ?>)<?php echo e(json_decode($status->detail,true)['rumah'] == "MW" ? ' selected="selected"' : ''); ?><?php endif; ?>>Menumpang wali</option>
												</select>
											</div>
										</div>
									</div>
									<?php if($status->status == ""): ?>
									<div class="row" id="toHide">
										<div class="col-md-10 col-md-offset-1">
											<div class="form-group">
												<label for="id_" class="control-label">Rekening Tabungan <star>*</star></label>
												<select class="form-control select2" id="tabungan" name="tab" style="width: 100%;">
													<option class="bs-title-option" selected disabled value="">-Pilih Rekening Tabungan-</option>
													<?php $__currentLoopData = $tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($rekening->id); ?>"> [<?php echo e($rekening->id_rekening); ?>] <?php echo e($rekening->nama_rekening); ?> </option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
												<span class="help-block"><star>*</star>Anda wajib membuat rekening Tabungan Awal untuk  pembagian SHU di akhir tahun!</span>
											</div>
										</div>
									</div>
									<?php endif; ?>
								</div>
							</div>
						</div>

						<div class="footer">
							<button type="button" class="btn btn-default btn-fill btn-wd btn-back pull-left">Kembali</button>

							<button type="button" class="btn btn-info btn-fill btn-wd btn-next pull-right">Selanjutnya</button>
							<div class="clearfix"></div>
						</div>
						</form>

					</div>
				</div>
				<div class="col-md-4">
					<style>
						.ui.card {
							display: inline-block;
							margin: 10px;
						}

						.ui.card,
						.ui.cards>.card {
							background-color: #5C5D5F;
							color: white;
						}

						.ui.card.matthew {
							background-color: #2B4B64;
						}
						.image button{
							position:absolute;
							top:5px;
							right:5px;
						}
						.ui.card>.content>a.header,
						.ui.cards>.card>.content>a.header,
						.ui.card .meta,
						.ui.cards>.card .meta,
						.ui.card>.content>.description,
						.ui.cards>.card>.content>.description,
						.ui.card>.extra a:not(.ui),
						.ui.cards>.card>.extra a:not(.ui) {
							color: white;
						}
					</style>
					<div class="ui card matthew">
						<div class="image">
							<img style="" src="<?php echo e(url('storage/public/file/'.json_decode($status->pathfile,true)['profile'])); ?>">
							<button type="button" class="btn btn-social btn-default btn-fill" data-toggle="modal" data-target="#editFoto" title="Ubah Foto">
								<i class="fa fa-photo"></i>
							</button>
						</div>
						<div class="content">
							<a class="header"><?php echo e($status->nama); ?></a>
							<div>
								<span class="date">Joined in <?php echo e(date_format($status->created_at,"Y F d")); ?></span>
							</div>
							<div class="description">
								<?php echo e($status->nama); ?>

							</div>
						</div>
						<div class="extra content">
							<a>
								<i class="fab span"></i>
							</a>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>

	<?php echo $__env->make('modal.anggota', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_script'); ?>


	<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
	<script src="<?php echo e(URL::asset('bootstrap/assets/js/moment.min.js')); ?>"></script>
	<!--  Date Time Picker Plugin is included in this js file -->
	<script src="<?php echo e(URL::asset('bootstrap/assets/js/bootstrap-datetimepicker.js')); ?>"></script>

	<script src="<?php echo e(URL::asset('bootstrap/assets/js/jquery.validate.min.js')); ?>"></script>
	<script src="<?php echo e(URL::asset('bootstrap/assets/js/jquery.bootstrap.wizard.min.js')); ?>"></script>
	<script type="text/javascript">
        $().ready(function(){

                var $validator = $("#wizardForm").validate({
                rules: {
                    email: {
                        required: true,
                        email: true,
                        minlength: 5
                    },
                    first_name: {
                        required: false,
                        minlength: 5
                    },
                    last_name: {
                        required: false,
                        minlength: 5
                    },
                    website: {
                        required: true,
                        minlength: 5,
                        url: true
                    },
                    framework: {
                        required: false,
                        minlength: 4
                    },
                    cities: {
                        required: true
                    },
                    price:{
                        number: true
                    }
                }
            });



            // you can also use the nav-pills-[blue | azure | green | orange | red] for a different color of wizard

            $('#wizardCard').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardForm').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });

        });

        function onFinishWizard(){
            //here you can do something, sent the form to server via ajax and show a success message with swal

            swal("Data disimpan!", "Terima kasih telah melengkapi data diri anda!", "success");
        }
	</script>

	<script type="text/javascript">
        $().ready(function(){
            // Init DatetimePicker
            demo.initFormExtendedDatetimepickers();
        });

        $('.currency').maskMoney({
            allowZero: true,
            precision: 0,
            thousands: ","
        });

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#pic')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(auto)
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        function readURL2(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#pic2')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(auto)
                };


                reader.readAsDataURL(input.files[0]);
            }
        }

        function readURL3(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#pic3')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(auto)
                };


                reader.readAsDataURL(input.files[0]);
            }
        }

        function readURL4(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#pic4')
                        .attr('src', e.target.result)
                        .width(400)
                        .height(auto)
                };


                reader.readAsDataURL(input.files[0]);
            }
        }

        type = ['','info','success','warning','danger'];
        demo = {
            showNotification: function(from, align){
                color = Math.floor((Math.random() * 4) + 1);

                $.notify({
                    icon: "pe-7s-gift",
                    message: "<b>Light Bootstrap Dashboard PRO</b> - forget about boring dashboards."

                },{
                    type: type[color],
                    timer: 4000,
                    placement: {
                        from: from,
                        align: align
                    }
                });
            },
            initFormExtendedDatetimepickers: function(){
                $('.datetimepicker').datetimepicker({
                    icons: {
                        time: "fa fa-clock-o",
                        date: "fa fa-calendar",
                        up: "fa fa-chevron-up",
                        down: "fa fa-chevron-down",
                        previous: 'fa fa-chevron-left',
                        next: 'fa fa-chevron-right',
                        today: 'fa fa-screenshot',
                        clear: 'fa fa-trash',
                        close: 'fa fa-remove'
                    }
                });
                $('.datepicker').datetimepicker({
//                    defaultDate: "11/1/2013",
                    defaultDate: '<?php echo e(isset(json_decode($status->detail,true)['tgl_lahir'])?json_decode($status->detail,true)['tgl_lahir']:""); ?>',
                    format: 'MM/DD/YYYY',
                    icons: {
                        time: "fa fa-clock-o",
                        date: "fa fa-calendar",
                        up: "fa fa-chevron-up",
                        down: "fa fa-chevron-down",
                        previous: 'fa fa-chevron-left',
                        next: 'fa fa-chevron-right',
                        today: 'fa fa-screenshot',
                        clear: 'fa fa-trash',
                        close: 'fa fa-remove'
                    }
                });

                $('.timepicker').datetimepicker({
//          format: 'H:mm',    // use this format if you want the 24hours timepicker
                    format: 'h:mm A',    //use this format if you want the 12hours timpiecker with AM/PM toggle
                    icons: {
                        time: "fa fa-clock-o",
                        date: "fa fa-calendar",
                        up: "fa fa-chevron-up",
                        down: "fa fa-chevron-down",
                        previous: 'fa fa-chevron-left',
                        next: 'fa fa-chevron-right',
                        today: 'fa fa-screenshot',
                        clear: 'fa fa-trash',
                        close: 'fa fa-remove'
                    }
                });
            },
        }

	</script>

	<script type="text/javascript">

        function stopRKey(evt) {
            var evt = (evt) ? evt : ((event) ? event : null);
            var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
            if ((evt.keyCode == 13) && (node.type=="text"))  {return false;}
        }

        document.onkeypress = stopRKey;

	</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>