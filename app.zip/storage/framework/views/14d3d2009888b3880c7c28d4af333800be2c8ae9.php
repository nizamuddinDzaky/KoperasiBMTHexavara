<footer class="footer footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul>
                <li>
                    <a href="<?php echo e(url('/')); ?>">
                        Home
                    </a>
                </li>
                <li>
                    <a href="http://www.bmtmuda.com/2012/01/profile-bmt.html">
                        Profile
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('maal')); ?>">
                        Maal
                    </a>
                </li>
            </ul>
        </nav>
        <p class="copyright pull-right">
            &copy;  <a href="#">BMT MUDA</a>, Baitul Maal Wat Tamwil Mandiri Ukhuwah Persada
        </p>
    </div>
</footer>