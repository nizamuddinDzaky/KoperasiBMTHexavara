

<iframe src="https://docs.google.com/viewer?embedded=true&url=<?php echo e(URL::asset($url)); ?>" frameborder="no" style="width:100%;height:100%"></iframe>








