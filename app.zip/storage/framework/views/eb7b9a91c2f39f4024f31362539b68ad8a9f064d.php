<?php $__env->startSection('side-navbar'); ?>
    <?php echo $__env->make('layouts.side_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-navbar'); ?>
    <?php echo $__env->make('layouts.top_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_style'); ?>
    <link href="<?php echo e(URL::asset('css/select2.min.css')); ?>" rel="stylesheet"/>
    <style>
        .fa-3x {
            font-size: 5vmax;}
        h3 {
            font-size: 2vw !important;}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="col-md-3" id="HideOptions">
                <div class="row-md-4">
                    <div class="col-md-12">
                        <div class="card card-wizard" style="">
                            <form id="wizardForm" method="" action="#">
                                <div class="header text-center">
                                   <span class="fa-stack fa-3x">
                                        <i class="fas fa-square fa-stack-2x" style="color:darkslateblue"></i>
                                        <i class="fas fa-credit-card fa-stack-1x fa-inverse"></i>
                                    </span>
                                    <h3 class="title">Deposito</h3>
                                    <p class="category">Pembukaan Deposito </p>
                                </div>

                                <div class="footer">
                                    <button type="button" class="btn btn-fill btn-block btn-info center-block" data-toggle="modal" data-target="#openDepModal">Deposito</button>
                                    <div class="clearfix"></div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="row-md-4">
                    <div class="col-md-12">
                        <div class="card card-wizard " style="">
                            <form id="wizardForm" method="" action="#">
                                <div class="header text-center">
                                <span class="fa-stack fa-3x">
                                    <i class="fas fa-square fa-stack-2x" style="color:darkorange"></i>
                                    <i class="fas fa-external-link-alt fa-stack-1x fa-inverse"></i>
                                </span>
                                    <h3 class="title">Perpanjangan</h3>
                                    <p class="category">Perpanjangan Deposito</p>
                                </div>

                                <div class="footer">
                                    <button type="button" class="btn btn-fill btn-block btn-info center-block"
                                            data-toggle="modal"
                                            data-target="#extendDepModal">Perpanjang</button>
                                    <div class="clearfix"></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="row-md-4">
                    <div class="col-md-12">
                        <div class="card card-wizard " style="">
                            <form id="wizardForm" method="" action="#">
                                <div class="header text-center">
                                <span class="fa-stack fa-3x">
                                    <i class="fas fa-square fa-stack-2x" style="color:darkgoldenrod"></i>
                                    <i class="fas fa-donate fa-stack-1x fa-inverse"></i>
                                </span>
                                    <h3 class="title">Pencairan</h3>
                                    <p class="category">Pencairan Deposito</p>
                                </div>

                                <div class="footer">
                                    <button type="button" class="btn btn-fill btn-block btn-info center-block"  data-toggle="modal" data-target="#withdrawDepModal">Pencairan</button>
                                    <div class="clearfix"></div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-9" id="ShowTable">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">

                            <div class="header text-center">
                                <h4 class="title"><b>Pengajuan Deposito </b></h4>
                                <p class="category">Daftar Pengajuan Deposito Nasabah</p>
                                <br />
                            </div>
                            <div class="toolbar">
                                <div class="row">
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4">
                                        
                                        <form <?php if(Auth::user()->tipe == "admin"): ?> action="<?php echo e(route('periode.pengajuan_deposito')); ?>" <?php elseif(Auth::user()->tipe == "teller"): ?> action="<?php echo e(route('teller.periode.pengajuan_deposito')); ?>" <?php endif; ?> method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <div align="center">
                                                <select required  name="periode" class="select pull-center" style="height: 1.9em">
                                                    <option disabled selected > - Periode -</option>
                                                    <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e(substr($p,0,4)."/".substr($p,5,6)); ?>"> <?php echo e(substr($p,0,4)); ?> - <?php echo e(substr($p,5,6)); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <button type="submit" class="btn btn-info btn-fill btn-sm"> <i class="pe-7s-search"></i> Search</button>

                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-md-4"></div>
                                </div>
                                <!--        Here you can write extra buttons/actions for the toolbar              -->
                                <span></span>
                            </div>

                            <table id="bootstrap-table" class="table">
                                <thead>
                                <th></th>
                                <th data-sortable="true" class="text-left">ID</th>
                                <th data-sortable="true">Jenis Pengajuan</th>
                                <th data-sortable="true">Keterangan</th>
                                <th data-sortable="true">Tgl Pengajuan</th>
                                <th data-sortable="true">Status</th>
                                <th data-sortable="true">Teller</th>
                                <th class="text-center">Actions</th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>
                                        <td class="text-left"><?php echo e($usr->id); ?></td>
                                        <td class="text-left"><?php echo e($usr->jenis_pengajuan); ?></td>
                                        <?php if(str_before($usr->kategori,' ')=="Debit" || str_before($usr->kategori,' ')=="Kredit" || str_before($usr->kategori,' ')=="Angsuran"): ?>
                                            <td class="text-center"><?php echo e($usr->kategori); ?></td>
                                        <?php else: ?>    <td class="text-center"><?php echo e(json_decode($usr->detail,true)['keterangan']); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($usr->created_at); ?></td>
                                        <td class="text-center text-uppercase"><?php echo e($usr->status); ?></td>
                                        <td class="text-center text-uppercase"><?php echo e($usr->teller); ?></td>

                                        <td class="td-actions text-center">
                                            <div class="row">
                                                <?php if(str_before($usr->kategori,' ')=="Pencairan"): ?>
                                                    <?php if($usr->status=="Sudah Dikonfirmasi" || $usr->status=="Disetujui"): ?>
                                                    <?php else: ?>
                                                        
                                                       
                                                <?php if(Auth::user()->tipe=="teller"): ?>
                                                    <button type="button" id="konfirm" class="btn btn-social btn-info btn-fill" data-toggle="modal" data-target="#confirm<?php echo e(substr($usr->kategori,0,3)); ?>Modal" title="Konfirmasi Pengajuan"
                                                                data-id       = "<?php echo e($usr->id); ?>"
                                                                data-nama     = "<?php echo e($usr->nama); ?>"
                                                                data-ktp     = "<?php echo e($usr->no_ktp); ?>"
                                                                data-iduser     = "<?php echo e(json_decode($usr->detail,true)['id']); ?>"
                                                                data-debit     = "<?php echo e(json_decode($usr->detail,true)[strtolower(str_before($usr->kategori,' '))]); ?>"
                                                                data-iddep     = "<?php echo e(json_decode($usr->detail,true)['id_deposito']); ?>"
                                                                data-atasnama   = "<?php echo e(json_decode($usr->detail,true)['atasnama']); ?>"
                                                                data-bank   = "<?php echo e(json_decode($usr->detail,true)['bank']); ?>"
                                                                data-nobank   = "<?php echo e(json_decode($usr->detail,true)['no_bank']); ?>"
                                                                data-jenis   = "<?php echo e(json_decode($usr->detail,true)['pencairan']); ?>"
                                                                data-kategori   = "<?php echo e($usr->kategori); ?>"
                                                                data-jumlah       = "<?php echo e(number_format(json_decode($usr->detail,true)['jumlah'],2)); ?>"
                                                                data-keterangan = "<?php echo e(json_decode($usr->detail,true)['keterangan']); ?>"
                                                                                                                        >
                                                            <i class="fa fa-check-square"></i>
                                                        </button>
                                                        <?php endif; ?>
                                                        <button type="button" class="btn btn-social btn-success btn-fill" data-toggle="modal" data-target="#editStatusModal" title="Ubah Status Pengajuan"
                                                                data-id      = "<?php echo e($usr->id); ?>"
                                                                data-id_user = "<?php echo e($usr->id_user); ?>"
                                                                data-nama    = "<?php echo e($usr->jenis_pengajuan); ?>">
                                                            <i class="fa fa-edit"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($usr->status=="Sudah Dikonfirmasi"  || $usr->status=="Disetujui"): ?>
                                                    <?php else: ?>
                                                        
                                                        <button type="button" id="active_" class="btn btn-social btn-info btn-fill" data-toggle="modal" data-target="#active<?php echo e(substr($usr->kategori,0,3)); ?>Modal" title="Aktivasi Rekening"
                                                                data-id         = "<?php echo e($usr->id); ?>"
                                                                data-namauser   = "<?php echo e(json_decode($usr->detail,true)['nama']); ?>"
                                                                data-ktp     = "<?php echo e($usr->no_ktp); ?>"
                                                                data-jumlah       = "<?php echo e(number_format(json_decode($usr->detail,true)['jumlah'])); ?>"
                                                                <?php if($usr->jenis_pengajuan =="Perpanjangan Deposito"): ?>
                                                                data-iduser     = "<?php echo e(json_decode($usr->detail,true)['id']); ?>"
                                                                data-atasnama   = "Pribadi"
                                                                data-kategori   = "<?php echo e(json_decode($usr->detail,true)['id_rekening_baru']); ?>"
                                                                data-keterangan = "<?php echo e(json_decode($usr->detail,true)['keterangan']); ?>"
                                                                <?php else: ?>
                                                                data-kategori   = "<?php echo e($usr->id_rekening); ?>"
                                                                data-keterangan = "<?php echo e(json_decode($usr->detail,true)['keterangan']); ?>"
                                                                data-atasnama   = "<?php echo e(json_decode($usr->detail,true)['atasnama']); ?>"
                                                                data-rek_tab       = "<?php echo e(isset(json_decode($usr->detail,true)['id_pencairan'])?json_decode($usr->detail,true)['id_pencairan']:""); ?>"
                                                                <?php endif; ?>
                                                        >
                                                            <i class="fa fa-check-square"></i>
                                                        </button>
                                                        <button type="button" class="btn btn-social btn-success btn-fill" data-toggle="modal" data-target="#editStatusModal" title="Ubah Status Pengajuan"
                                                                data-id      = "<?php echo e($usr->id); ?>"
                                                                data-id_user = "<?php echo e($usr->id_user); ?>"
                                                                data-nama    = "<?php echo e($usr->jenis_pengajuan); ?>">
                                                            <i class="fa fa-edit"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                            <div class="row">
                                                
                                                <button type="button" id="detail" class="btn btn-social btn-primary btn-fill" data-toggle="modal" data-target="#view<?php echo e(substr($usr->kategori,0,3)); ?>Modal" title="View Detail"
                                                        data-id         = "<?php echo e($usr->id); ?>"
                                                        data-namauser   = "<?php echo e(json_decode($usr->detail,true)['nama']); ?>"
                                                        data-ktp     = "<?php echo e($usr->no_ktp); ?>"

                                                        <?php if(str_before($usr->kategori,' ')=="Debit" || str_before($usr->kategori,' ')=="Kredit"): ?>
                                                        data-nama     = "<?php echo e($usr->nama); ?>"
                                                        data-ktp     = "<?php echo e($usr->no_ktp); ?>"
                                                        data-iduser     = "<?php echo e(json_decode($usr->detail,true)['id']); ?>"
                                                        data-debit     = "<?php echo e(json_decode($usr->detail,true)[strtolower(str_before($usr->kategori,' '))]); ?>"
                                                        data-jumlah     = "<?php echo e(number_format(json_decode($usr->detail,true)['jumlah'])); ?>"
                                                        data-bank     = "<?php echo e(json_decode($usr->detail,true)['bank']); ?>"
                                                            <?php if(str_before($usr->kategori,' ')=="Debit"): ?>
                                                            data-path     = "<?php echo e(url('/storage/public/transfer/'.json_decode($usr->detail,true)['path_bukti'])); ?>"
                                                            data-idtab     = "<?php echo e(json_decode($usr->detail,true)['id_tabungan']); ?>"
                                                            data-atasnamabank     = "<?php echo e(isset(json_decode($usr->detail,true)['atasnama'])?json_decode($usr->detail,true)['atasnama']:''); ?>"
                                                            data-banktr     = "<?php echo e(isset(json_decode($usr->detail,true)['daribank'])?json_decode($usr->detail,true)['daribank']:''); ?>"
                                                            data-no_banktr     = "<?php echo e(isset(json_decode($usr->detail,true)['no_bank'])?json_decode($usr->detail,true)['no_bank']:''); ?>"
                                                            <?php elseif(str_before($usr->kategori,' ')=="Kredit"): ?>
                                                            data-saldo     = "<?php echo e(number_format(json_decode($usr->detail_tabungan,true)['saldo'])); ?>"
                                                            data-atasnama     = "<?php echo e(json_decode($usr->detail,true)['atasnama']); ?>"
                                                            data-no_bank   = "<?php echo e(json_decode($usr->detail,true)['no_bank']); ?>"
                                                            data-idtab     = "<?php echo e($usr->id_tabungan); ?>"
                                                            <?php endif; ?>
                                                        <?php elseif($usr->kategori =="Perpanjangan Deposito"): ?>
                                                        data-iduser     = "<?php echo e(json_decode($usr->detail,true)['id']); ?>"
                                                        data-iddep     = "<?php echo e(json_decode($usr->detail,true)['id_deposito']); ?>"
                                                        data-saldo    = "<?php echo e(number_format(json_decode($usr->detail,true)['saldo'],2)); ?>"
                                                        data-atasnama   = "Pribadi"
                                                        data-kategori   = "<?php echo e(json_decode($usr->detail,true)['id_rekening_baru']); ?>"
                                                        data-jumlah     = "<?php echo e(number_format(json_decode($usr->detail,true)['jumlah'])); ?>"
                                                        <?php elseif(str_before($usr->kategori,' ')=="Pencairan"): ?>
                                                        data-jumlah     = "<?php echo e(number_format(json_decode($usr->detail,true)['jumlah'])); ?>"
                                                        data-iddep     = "<?php echo e(json_decode($usr->detail,true)['id_deposito']); ?>"
                                                        data-atasnama   = "<?php echo e(json_decode($usr->detail,true)['atasnama']); ?>"
                                                        data-bank   = "<?php echo e(json_decode($usr->detail,true)['bank']); ?>"
                                                        data-nobank   = "<?php echo e(json_decode($usr->detail,true)['no_bank']); ?>"
                                                        data-jenis   = "<?php echo e(json_decode($usr->detail,true)['pencairan']); ?>"
                                                        data-kategori   = "<?php echo e($usr->kategori); ?>"
                                                        data-keterangan = "<?php echo e(json_decode($usr->detail,true)['keterangan']); ?>"
                                                        <?php elseif($usr->kategori=="Angsuran Pembiayaan"): ?>
                                                        data-idtab = "<?php echo e(json_decode($usr->detail,true)['id_pembiayaan']); ?>"
                                                        data-namatab = "<?php echo e(json_decode($usr->detail,true)['nama_pembiayaan']); ?>"
                                                        data-bankuser = "<?php echo e(json_decode($usr->detail,true)['bank_user']); ?>"
                                                        data-no_bank = "<?php echo e(json_decode($usr->detail,true)['no_bank']); ?>"
                                                        data-atasnama = "<?php echo e(json_decode($usr->detail,true)['nama']); ?>"
                                                        data-jenis = "<?php echo e(json_decode($usr->detail,true)['angsuran']); ?>"
                                                        data-pokok = "<?php echo e(number_format(json_decode($usr->detail,true)['pokok'],2)); ?>"
                                                        data-bank = "<?php echo e(json_decode($usr->detail,true)['bank']); ?>"
                                                        data-keterangan = "<?php echo e(json_decode($usr->detail,true)['nama_pembiayaan']); ?>"
                                                        data-path       = "<?php echo e(url('/storage/public/transfer/'.json_decode($usr->detail,true)['path_bukti'] )); ?>"
                                                        data-jumlah       = "<?php echo e(number_format(json_decode($usr->detail,true)['jumlah'],2)); ?>"
                                                        <?php else: ?>
                                                        data-kategori   = "<?php echo e($usr->id_rekening); ?>"
                                                        data-atasnama   = "<?php echo e(json_decode($usr->detail,true)['atasnama']); ?>"
                                                        data-keterangan = "<?php echo e(json_decode($usr->detail,true)['keterangan']); ?>"
                                                        <?php endif; ?>

                                                        <?php if($usr->kategori=="Tabungan" || $usr->kategori=="Tabungan Awal"): ?>
                                                        data-akad       = "<?php echo e(json_decode($usr->detail,true)['akad']); ?>"
                                                        <?php elseif($usr->kategori=="Pembiayaan"): ?>
                                                        data-jumlah       = "<?php echo e(number_format(json_decode($usr->detail,true)['jumlah'])); ?>"
                                                        data-jenis       = "<?php echo e(json_decode($usr->detail,true)['jenis_Usaha']); ?>"
                                                        data-usaha       = "<?php echo e(json_decode($usr->detail,true)['usaha']); ?>"
                                                        data-jaminan       = "<?php echo e(json_decode($usr->detail,true)['jaminan']); ?>"
                                                        data-waktu       = "<?php echo e(str_before(json_decode($usr->detail,true)['keterangan'],' ')); ?>"
                                                        data-ketwaktu       = "<?php echo e(str_after(json_decode($usr->detail,true)['keterangan'],' ')); ?>"
                                                        data-path       = "<?php echo e(url('/storage/public/'.json_decode($usr->detail,true)['path_jaminan'])); ?>"
                                                        <?php elseif($usr->kategori=="Deposito"): ?>
                                                        data-jumlah       = "<?php echo e(number_format(json_decode($usr->detail,true)['jumlah'])); ?>"
                                                        data-rek_tab       = "<?php echo e(isset(json_decode($usr->detail,true)['id_pencairan'])?json_decode($usr->detail,true)['id_pencairan']:""); ?>"
                                                        data-nisbah       = "<?php echo e(json_decode($usr->deposito,true)['nisbah_anggota']); ?>"
                                                        <?php endif; ?>
                                                >
                                                    <i class="fa fa-list-alt"></i>
                                                </button>
                                                <?php if(str_before($usr['status']," ")=="Disetujui" || str_before($usr['status']," ")=="Sudah"): ?>
                                                    <?php if($usr['kategori']=="Deposito"): ?>
                                                        
                                                        <?php echo e(csrf_field()); ?>

                                                        
                                                        
                                                        <a <?php if(Auth::user()->tipe == "admin"): ?> href="<?php echo e(route('akad.pengajuan_deposito', [$usr['id']])); ?>" <?php elseif(Auth::user()->tipe == "teller"): ?> href="<?php echo e(route('teller.akad.pengajuan_deposito', [$usr['id']])); ?>" <?php endif; ?>  class="btn btn-social btn-fill" title="Download Akad">
                                                            <i class="fa fa-file"></i>
                                                        </a>
                                                        
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <button type="button"  class="btn btn-social btn-danger btn-fill" data-toggle="modal" data-target="#delModal" title="Delete"
                                                            data-id       = "<?php echo e($usr->id); ?>"
                                                            data-nama     = "<?php echo e($usr->jenis_pengajuan); ?>">
                                                        <i class="fa fa-remove"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div><!--  end card  -->
                    </div> <!-- end col-md-12 -->
                </div> <!-- end row -->
            </div>
        </div>
    </div>
    <?php echo $__env->make('modal.pengajuan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('modal.user_deposito', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_script'); ?>


    <!--  Plugin for Date Time Picker and Full Calendar Plugin-->

<?php $__env->startSection('extra_script'); ?>
    

    <!-- Select2 plugin -->
    <script src=" <?php echo e(URL::asset('/js/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        //  DEPOSITO
        $('#viewDepModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            $('#vrekDep').val(button.data('kategori'));
            var selAr = $('#toHide3v');
            var selAr2 = $('#toHide4v');
            if(button.data('atasnama')==="Lembaga"){
                $('#vatasnama2').val(2);
                $('#vidhukum2').val(button.data('iduser'));
                $('#vnamahukum2').val(button.data('namauser'));
                selAr2.show();
                selAr.hide();
            }else if(button.data('atasnama')==="Pribadi"){
                $('#vatasnama2').val(1);
                $('#viduser2').val(button.data('ktp'));
                $('#vnama2').val(button.data('namauser'));
                selAr2.hide();
                selAr.show();
            }
            $('#vket_nisbah').val(button.data('nisbah'));
            $('#vrek_tabungan').val(button.data('rek_tab'));
            $('#vketerangan2').val(button.data('keterangan'));
            $('#vjumlahdep').val(button.data('jumlah'));
        });
        $('#viewPerModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            $('#vexidRek').val(button.data('iddep'));
            $('#vlama').val(button.data('kategori'));
            $('#vsaldo_per').val(button.data('saldo'));
            $('#vketerangan').val(button.data('keterangan'));
            $('#vextjumlah').val(button.data('jumlah'));
        });
        $('#viewPenModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var selAr = $('#toHidePenv');
            var selAr2 = $('#toHidePen2v');
            if(button.data('jenis')=== "Transfer"){
                selAr2.show();
                selAr.show();
            }else{
                selAr2.hide();
                selAr.hide();
            }
            $('#vjenisPen').val(button.data('jenis'));
            $('#vatasnamaPen').val(button.data('atasnama'));
            $('#vnobankPen').val(button.data('nobank'));
            $('#vbankPen').val(button.data('bank'));

            $('#vwidRek').val(button.data('iddep'));
            $('#vwketerangan').val(button.data('keterangan'));
            $('#vwjumlah').val(button.data('jumlah'));
        });
        $('#confirmPenModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            var selAr = $('#toHidePenc');
            var selAr2 = $('#toHidePen2c');
            if(button.data('jenis')=== "Transfer"){
                $('#toHidePenT').hide();
                $('#tellerpen').attr("required",false);
                $('#toHidePenB').show();
                selAr2.show();
                selAr.show();

            }else if(button.data('jenis')=== "Tunai"){
                $('#toHidePenT').show();
                $('#toHidePenB').hide();
                $('#bankpen').attr("required",false);
                selAr2.hide();
                selAr.hide();
            }
            $('#cjenisPen').val(button.data('jenis'));
            $('#catasnamaPen').val(button.data('atasnama'));
            $('#cnobankPen').val(button.data('nobank'));
            $('#cbankPen').val(button.data('bank'));

            $('#cwidRek').val(button.data('iddep'));
            $('#idPen').val(button.data('id'));
            $('#cwketerangan').val(button.data('keterangan'));
            $('#cwjumlah').val(button.data('jumlah'));
            $('#penjumlah').val(button.data('jumlah'));
        });
        $('#activeDepModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            $('#arekDep').val(button.data('kategori'));
            var selAr = $('#toHide3a');
            var selAr2 = $('#toHide4a');
            console.log(button.data('iduser'));
            console.log(button.data('namauser'));
            if(button.data('atasnama')==="Lembaga"){
                $('#aatasnama2').val(2);
                $('#aidhukum2').val(button.data('iduser'));
                $('#anamahukum2').val(button.data('namauser'));
                selAr2.show();
                selAr.hide();
            }else if(button.data('atasnama')==="Pribadi"){
                $('#aatasnama2').val(1);
                $('#aiduser2').val(button.data('ktp'));
                $('#anama2').val(button.data('namauser'));
                selAr2.hide();
                selAr.show();
            }
            $('#aket_nisbah').val(button.data('nisbah'));
            $('#arek_tabungan').val(button.data('rek_tab'));
            $('#ajumlahdep').val(button.data('jumlah'));
            $('#aketerangan2').val(button.data('keterangan'));
            $('#id_act_dep').val(button.data('id'));
        });

        $('#activePengajuanModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('id');
            var id_user = button.data('id');
            var nama = button.data('nama');
            var kategori = button.data('kategori');
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            $('#id_active').val(id);
            $('#id_active_user').val(id_user);
            $('#ActiveLabel').text("Aktivasi Akun : " + nama);
            $('#toActive').text(nama + "?");
        });
        $('#editStatusModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('id');
            var id_user = button.data('id');
            var nama = button.data('nama');
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            $('#id_status').val(id);
            $('#id_status_user').val(id_user);
            $('#StatusLabel').text("Ubah Status : " + nama);
            $('#toStatus').text(nama + "?");
        });
        $('#delModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('id');
            var nama = button.data('nama');
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            $('#id_del').val(id);
            $('#delTabLabel').text("Hapus Pengajuan : " + nama);
            $('#toDelete').text(nama + "?");
        });
    </script>

    <script type="text/javascript">
        var $table = $('#bootstrap-table');


        $().ready(function(){
            $('#bootstrap-table').dataTable({
                initComplete: function () {
                    $('.buttons-pdf').html('<span class="fas fa-file" data-toggle="tooltip" title="Export To Pdf"/> PDF')
                    $('.buttons-print').html('<span class="fas fa-print" data-toggle="tooltip" title="Print Table"/> Print')
                    $('.buttons-copy').html('<span class="fas fa-copy" data-toggle="tooltip" title="Copy Table"/> Copy')
                    $('.buttons-excel').html('<span class="fas fa-paste" data-toggle="tooltip" title="Export to Excel"/> Excel')
                },
                "processing": true,
//                "dom": 'lBf<"top">rtip<"clear">',
                "order": [],
                "scrollX": false,
                "dom": 'lBfrtip',
                "buttons": {
                    "dom": {
                        "button": {
                            "tag": "button",
                            "className": "waves-effect waves-light btn mrm"
//                            "className": "waves-effect waves-light btn-info btn-fill btn mrm"
                        }
                    },
                    "buttons": [
                        'copyHtml5',
                        'print',
                        'excelHtml5',
//                        'csvHtml5',
                        'pdfHtml5' ]
                }
            });
//            $table.bootstrapTable({
//                toolbar: ".toolbar",
//                clickToSelect: true,
//                showRefresh: true,
//                search: true,
//                showToggle: true,
//                showColumns: true,
//                pagination: true,
//                searchAlign: 'left',
//                pageSize: 8,
//                clickToSelect: false,
//                pageList: [8,10,25,50,100],
//
//                formatShowingRows: function(pageFrom, pageTo, totalRows){
//                    //do nothing here, we don't want to show the text "showing x of y from..."
//                },
//                formatRecordsPerPage: function(pageNumber){
//                    return pageNumber + " rows visible";
//                },
//                icons: {
//                    refresh: 'fa fa-refresh',
//                    toggle: 'fa fa-th-list',
//                    columns: 'fa fa-columns',
//                    detailOpen: 'fa fa-plus-circle',
//                    detailClose: 'fa fa-minus-circle'
//                }
//            });
//
//            //activate the tooltips after the data table is initialized
//            $('[rel="tooltip"]').tooltip();
//
//            $(window).resize(function () {
//                $table.bootstrapTable('resetView');
//            });


        });

    </script>
    <script type="text/javascript">
        $().ready(function(){

            var selNisbah = $('#rekDep');
            var id = 0;
            var nisbah =0;
            selNisbah.on('change', function () {
                id = parseFloat(selNisbah.val().split(' ')[0]);
                nisbah = parseFloat(selNisbah.val().split(' ')[1]);
                $('#deposito_id').val(id);
                $('#ket_nisbah').val(nisbah);
            });

            var selKr = $('#toHidePen');
            var selKr2 = $('#toHidePen2');

            var selKrc = $('#toHidePenBC');
            var selKr2c = $('#toHidePenTC');

            var jenisK = $('#jenisPen');
            jenisK.val(0);
            selKr.hide();
            selKr2.hide();
            selKrc.hide();
            var aPen  =$('#atasnamaPen');
            var nbPen  =$('#nobankPen');
            var bPen =$('#bankPen');
            var tPenc =$('#tellerpenc');
            var bPenc =$('#bankpenc');
            bPenc.attr("required",false);
            jenisK.on('change', function () {
                if(jenisK .val() == 1) {
                    selKr.show();
                    selKr2.show();
                    selKrc.show();
                    selKr2c.hide();
                    selKr2c.val("");
                    tPenc.val("");
                    bPenc.attr("required",true);
                    tPenc.attr("required",false);
                    aPen.attr("required",true);
                    bPen.attr("required",true);
                    nbPen.attr("required",true);
                }
                else if (jenisK .val() == 0) {
                    aPen.attr("required",false);
                    bPen.attr("required",false);
                    nbPen.attr("required",false);
                    bPenc.attr("required",false);
                    tPenc.attr("required",true);
                    bPenc.val("");
                    selKr.hide();
                    selKrc.val("");
                    selKrc.hide();
                    selKr2c.show();
                    selKr2.hide();
                }
            });

            var selTip3 = $('#widRek');
            selTip3.on('change', function () {
                var id = $('#idRekWD').val(selTip3.find(":selected").text().split(']')[0]);
                id = id.val().split('[')[1];
                $('#idRekWD').val(id);
                console.log(id);
                $('#wjumlah').val(selTip3.val());
                $('#saldo_teller').val(selTip3.val());
            });

            var selTip = $('#exidRek');
            selTip.on('change', function () {
                var id = $('#idRekSP').val(selTip.find(":selected").text().split(']')[0]);
                id = id.val().split('[')[1];
                $('#idRekSP').val(id);
                $('#extjumlah').val(selTip.val())
            });

            $('#saldo_per').on('keyup keydown', function(e){
                if ($(this).val() > parseInt(selTip.val())
                    && e.keyCode != 46
                    && e.keyCode != 8
                ) {
                    e.preventDefault();
                    $(this).val(parseInt(selTip.val()));
                }
            });

            var selAr3 = $('#toHide3');
            var selAr4 = $('#toHide4');
            var selTip2 = $('#atasnama2');
            var selHk2 = $('#idhukum2');
            var selHkn2 = $('#namahukum2');
            selAr3.hide();
            selAr4.hide();

            var selTip22 = $('#nasabah2');

            selTip22.on('change', function () {
                $('#namauser2').val($('#nasabah2').find(":selected").text())
                $('#id_user2').val($('#nasabah2').val())
                console.log($('#id_user2').val());
                console.log($('#namauser2').val());

            });

            selTip2.on('change', function () {
                    if (selTip2.val() == 1) {
                        selAr3.show();
                        selAr4.hide();
                        selHk2.val("null");
                        selHkn2.val("null");
                    }
                    else {
                        selAr4.show();
                        selAr3.hide();
                        selHk2.val("");
                        selHkn2.val("");
                    }
            });

            var allOptions = $('#rek_tabungan option')
            $('#nasabah2').change(function () {
                $('#rek_tabungan option').remove()
                var classN = $('#nasabah2 option:selected').prop('class');
                var opts = allOptions.filter('.' + classN);
                $.each(opts, function (i, j) {
                    $(j).appendTo('#rek_tabungan');
                });
            });

            $("#rekAkad").select2({
                dropdownParent: $("#openTabModal")
            });
            $("#rekTab").select2({
                dropdownParent: $("#openTabModal")
            });
            $("#rekDep").select2({
                dropdownParent: $("#openDepModal")
            });
            $("#nasabah2").select2({
                dropdownParent: $("#openDepModal")
            });
            $("#rek_tabungan").select2({
                dropdownParent: $("#openDepModal")
            });
            $("#exidRek").select2({
                dropdownParent: $("#extendDepModal")
            });
            $("#widRek").select2({
                dropdownParent: $("#withdrawDepModal")
            });
            $("#rekPem").select2({
                dropdownParent: $("#openPemModal")
            });

            lbd.checkFullPageBackgroundImage();

            setTimeout(function(){
                // after 1000 ms we add the class animated to the login/register card
                $('.card').removeClass('card-hidden');
            }, 700);
        });
    </script>
    <script type="text/javascript">
        $().ready(function(){
            // Init DatetimePicker
            demo.initFormExtendedDatetimepickers();

        });
        type = ['','info','success','warning','danger'];
        demo = {
            showNotification: function(from, align){
                color = Math.floor((Math.random() * 4) + 1);

                $.notify({
                    icon: "pe-7s-gift",
                    message: "<b>Light Bootstrap Dashboard PRO</b> - forget about boring dashboards."

                },{
                    type: type[color],
                    timer: 4000,
                    placement: {
                        from: from,
                        align: align
                    }
                });
            },
            initFormExtendedDatetimepickers: function(){
                $('.datetimepicker').datetimepicker({
                    icons: {
                        time: "fa fa-clock-o",
                        date: "fa fa-calendar",
                        up: "fa fa-chevron-up",
                        down: "fa fa-chevron-down",
                        previous: 'fa fa-chevron-left',
                        next: 'fa fa-chevron-right',
                        today: 'fa fa-screenshot',
                        clear: 'fa fa-trash',
                        close: 'fa fa-remove'
                    }
                });

                $('.datepicker').datetimepicker({
                    format: 'MM/DD/YYYY',
                    icons: {
                        time: "fa fa-clock-o",
                        date: "fa fa-calendar",
                        up: "fa fa-chevron-up",
                        down: "fa fa-chevron-down",
                        previous: 'fa fa-chevron-left',
                        next: 'fa fa-chevron-right',
                        today: 'fa fa-screenshot',
                        clear: 'fa fa-trash',
                        close: 'fa fa-remove'
                    }
                });

                $('.timepicker').datetimepicker({
//          format: 'H:mm',    // use this format if you want the 24hours timepicker
                    format: 'h:mm A',    //use this format if you want the 12hours timpiecker with AM/PM toggle
                    icons: {
                        time: "fa fa-clock-o",
                        date: "fa fa-calendar",
                        up: "fa fa-chevron-up",
                        down: "fa fa-chevron-down",
                        previous: 'fa fa-chevron-left',
                        next: 'fa fa-chevron-right',
                        today: 'fa fa-screenshot',
                        clear: 'fa fa-trash',
                        close: 'fa fa-remove'
                    }
                });
            },
        }
    </script>
     


    <script src="<?php echo e(URL::asset('bootstrap/assets/js/moment.min.js')); ?>"></script>
    <!--  Date Time Picker Plugin is included in this js file -->
    <script src="<?php echo e(URL::asset('bootstrap/assets/js/bootstrap-datetimepicker.js')); ?>"></script>

    <script src="<?php echo e(URL::asset('bootstrap/assets/js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('bootstrap/assets/js/jquery.bootstrap.wizard.min.js')); ?>"></script>
    <script type="text/javascript">
        $().ready(function(){

            var $validator = $("#wizardForm").validate({
                rules: {
                    email: {
                        required: true,
                        email: true,
                        minlength: 5
                    },
                    first_name: {
                        required: false,
                        minlength: 5
                    },
                    last_name: {
                        required: false,
                        minlength: 5
                    },
                    website: {
                        required: true,
                        minlength: 5,
                        url: true
                    },
                    framework: {
                        required: false,
                        minlength: 4
                    },
                    cities: {
                        required: true
                    },
                    price:{
                        number: true
                    }
                }
            });

            // you can also use the nav-pills-[blue | azure | green | orange | red] for a different color of wizard


            //            DEPOSITO
            $('#wizardCard2').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardForm2').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });
            $('#wizardCard2a').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardForm2a').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });
            $('#wizardCard2v').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardForm2v').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });
            $('#wizardCardDep').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardFormDep').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });
            $('#wizardCardDepv').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardFormDepv').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });
            $('#wizardCardW').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardFormW').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });
            $('#wizardCardWv').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardFormWv').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });
            $('#wizardCardWc').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardFormWc').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });


        });

        function onFinishWizard(){
            //here you can do something, sent the form to server via ajax and show a success message with swal

            swal("Data disimpan!", "Terima kasih telah melengkapi data diri anda!", "success");
        }
    </script>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>