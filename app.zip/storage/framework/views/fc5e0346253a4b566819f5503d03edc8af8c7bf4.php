<?php $__env->startSection('side-navbar'); ?>
    <?php echo $__env->make('layouts.side_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-navbar'); ?>
    <?php echo $__env->make('layouts.top_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_style'); ?>
    <link href="<?php echo e(URL::asset('css/select2.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header text-center">
                            <h4 class="title"><b>Datamaster Pembiayaan BMT</b></h4>
                            <p class="category">Daftar Rekening Pembiayaan</p>
                            
                        </div>

                        <div class="toolbar">
                            <!--        Here you can write extra buttons/actions for the toolbar              -->
                            <div class="col-md-12 btn-group">
                                <button type="button" class="btn btn-primary btn-fill" style="margin-bottom:1em" data-toggle="modal" data-target="#addPemModal" title="Tambah Pembiayaan">Tambah Pembiayaan
                                    <i class="pe-7s-add-user"></i>
                                </button>
                            </div>
                            <span></span>
                        </div>

                        <table id="bootstrap-table" class="table">
                            <thead>
                            <th></th>
                            
                            <th data-field="id" data-sortable="true" class="text-left">ID Pembiayaan</th>
                            <th data-field="idRek" data-sortable="true">ID Rekening</th>
                            <th data-field="nama" data-sortable="true">Jenis Pembiayaan</th>
                            <th data-field="nisbah" data-sortable="true">Nisbah</th>
                            <th data-field="saldo" data-sortable="true">Saldo Minimal</th>
                            
                            <th>Actions</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>
                                    <td><?php echo e($pem->id); ?></td>
                                    <td><?php echo e($pem->id_rekening); ?></td>
                                    <td><?php echo e($pem->nama_rekening); ?></td>
                                    <td><?php echo e($pem->nisbah); ?>%</td>
                                    <td><?php echo e(number_format($pem->saldo_minimal)); ?></td>
                                    <td class="td-actions text-center">
                                        <button type="button" class="btn btn-social btn-success btn-fill" data-toggle="modal" data-target="#editPemModal" title="Edit"
                                                data-id         = "<?php echo e($pem->id); ?>"
                                                data-idpemb      = "<?php echo e($pem->id_rekening); ?>"
                                                data-idrek      = "<?php echo e($pem->id_rekening); ?>"
                                                data-tipe      = "<?php echo e($pem->tipe_rekening); ?>"
                                                data-rekmar    = "<?php echo e(json_decode($pem->detail,true)['rek_margin']); ?>"
                                                data-rekmt    = "<?php echo e(json_decode($pem->detail,true)['m_ditangguhkan']); ?>"
                                                data-rekden    = "<?php echo e(json_decode($pem->detail,true)['rek_denda']); ?>"
                                                data-rekadm      = "<?php echo e(json_decode($pem->detail,true)['rek_administrasi']); ?>"
                                                data-reknot      = "<?php echo e(json_decode($pem->detail,true)['rek_notaris']); ?>"
                                                data-rekwo      = "<?php echo e(json_decode($pem->detail,true)['rek_pend_WO']); ?>"
                                                data-rekmat    = "<?php echo e(json_decode($pem->detail,true)['rek_materai']); ?>"
                                                data-rekasu    = "<?php echo e(json_decode($pem->detail,true)['rek_asuransi']); ?>"
                                                data-rekprov      = "<?php echo e(json_decode($pem->detail,true)['rek_provisi']); ?>"
                                                data-rekppro   = "<?php echo e(json_decode($pem->detail,true)['rek_pend_prov']); ?>"
                                                data-rekzis   = "<?php echo e(json_decode($pem->detail,true)['rek_zis']); ?>"
                                                data-piutang      = "<?php echo e(json_decode($pem->detail,true)['piutang']); ?>"
                                                data-pinjam    = "<?php echo e(json_decode($pem->detail,true)['jenis_pinjaman']); ?>">
                                        <i class="fa fa-edit"></i>
                                        </button>
                                        <button type="button" class="btn btn-social btn-danger btn-fill" data-toggle="modal" data-target="#delPemModal" title="Edit"
                                                data-id         = "<?php echo e($pem->id); ?>"
                                                data-idrek      = "<?php echo e($pem->id_rekening); ?>"
                                                data-namapem    = "<?php echo e($pem->jenis_pembiayaan); ?>">
                                            <i class="fa fa-remove"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div><!--  end card  -->
                </div> <!-- end col-md-12 -->
            </div> <!-- end row -->

        </div>
    </div>

    <?php echo $__env->make('modal.pembiayaan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_script'); ?>

    <script type="text/javascript">
//        $('#editRekModal').on('hidden.bs.modal', function () {
//            if (!$('#editRekModal').hasClass('no-reload')) {
//                location.reload();
//            }
//        });
        $('#editPemModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('id');
            var idrek = button.data('idrek');
            var iddep = button.data('iddep');
            var nama = button.data('tipe');
                // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            $('#id_edit').val(idrek);
            $('#id_depo').val(iddep);
            $('#id_rek').val(idrek);
            $('#nama').val(nama);
            $('#editrekMar').val(button.data('rekmar'));
            $('#editrekMt').val(button.data('rekmt'));
            $('#editrekDen').val(button.data('rekden'));
            $('#editrekAdm').val(button.data('rekadm'));
            $('#editrekNot').val(button.data('reknot'));
            $('#editrekWO').val(button.data('rekwo'));
            $('#editrekMat').val(button.data('rekmat'));
            $('#editrekAsu').val(button.data('rekasu'));
            $('#editrekProv').val(button.data('rekprov'));
            $('#editrekPpro').val(button.data('rekppro'));
            $('#editrekZis').val(button.data('rekzis'));
            $('#editpiutang').val(button.data('piutang'));
            $('#editpinjam').val(button.data('pinjam'));
            $('#editPemLabel').text("Edit : " + nama);
            var mTangguh2 = $('#toHideMedit');
            if($('#editpiutang').val() == 1) {
                mTangguh2.show();
                $('#editrekMt').attr("required",true);
            }
            else if($('#editpiutang').val() == 0) {
                mTangguh2.hide();
                $('#editrekMt').attr("required",false);
            }
        });

        $('#delPemModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('idrek');
            var nama = button.data('namapem');
            // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
            // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
            $('#id_del').val(id);
            $('#delPemLabel').text("Hapus : " + nama);
            $('#toDelete').text(nama + " akan dihapus!");
        });

    </script>

    <!-- Select2 plugin -->
    <script src=" <?php echo e(URL::asset('/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('bootstrap/assets/js/jquery.bootstrap.wizard.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {

            var mTangguh = $('#toHideM');
            var piutang = $('#piutang');
            mTangguh.hide();
            piutang.on('change', function () {
                if(piutang .val() == 1) {
                    mTangguh.show();
                    $('#addrekMt').attr("required",true);
                }
                else if(piutang .val() == 0) {
                    mTangguh.hide();
                    $('#addrekMt').attr("required",false);
                }
            });
            var mTangguh2 = $('#toHideMedit');
            var piutang2 = $('#editpiutang');
            mTangguh2.hide();
            piutang2.on('change', function () {
                if(piutang2 .val() == 1) {
                    mTangguh2.show();
                    $('#editrekMt').attr("required",true);
                }
                else if(piutang2 .val() == 0) {
                    mTangguh2.hide();
                    $('#editrekMt').attr("required",false);
                }
            });


                $("#idRek").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekMar").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekDen").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekMt").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekAdm").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekNot").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekWO").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekMat").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekAsu").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekProv").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekPpro").select2({
                dropdownParent: $("#addPemModal")
            });
            $("#addrekZis").select2({
                dropdownParent: $("#addPemModal")
            });

            $("#editrekMar").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekDen").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekMt").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekAdm").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekNot").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekWO").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekMat").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekAsu").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekProv").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekPpro").select2({
                dropdownParent: $("#editPemModal")
            });
            $("#editrekZis").select2({
                dropdownParent: $("#editPemModal")
            });

            lbd.checkFullPageBackgroundImage();

            setTimeout(function(){
                // after 1000 ms we add the class animated to the login/register card
                $('.card').removeClass('card-hidden');
            }, 700);

            var $validator = $("#wizardForm").validate({
                rules: {
                    email: {
                        required: true,
                        email: true,
                        minlength: 5
                    },
                    first_name: {
                        required: false,
                        minlength: 5
                    },
                    last_name: {
                        required: false,
                        minlength: 5
                    },
                    website: {
                        required: true,
                        minlength: 5,
                        url: true
                    },
                    framework: {
                        required: false,
                        minlength: 4
                    },
                    cities: {
                        required: true
                    },
                    price:{
                        number: true
                    }
                }
            });

            $('#wizardCard').bootstrapWizard({
                tabClass: 'nav nav-pills',
                nextSelector: '.btn-next',
                previousSelector: '.btn-back',
                onNext: function(tab, navigation, index) {
                    var $valid = $('#wizardForm').valid();

                    if(!$valid) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onInit : function(tab, navigation, index){

                    //check number of tabs and fill the entire row
                    var $total = navigation.find('li').length;
                    $width = 100/$total;

                    $display_width = $(document).width();

                    if($display_width < 600 && $total > 3){
                        $width = 50;
                    }

                    navigation.find('li').css('width',$width + '%');
                },
                onTabClick : function(tab, navigation, index){
                    // Disable the posibility to click on tabs
                    return false;
                },
                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var wizard = navigation.closest('.card-wizard');

                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $(wizard).find('.btn-next').hide();
                        $(wizard).find('.btn-finish').show();
                    } else if($current == 1){
                        $(wizard).find('.btn-back').hide();
                    } else {
                        $(wizard).find('.btn-back').show();
                        $(wizard).find('.btn-next').show();
                        $(wizard).find('.btn-finish').hide();
                    }
                }

            });

        });
    </script>

    <script type="text/javascript">
        var $table = $('#bootstrap-table');

        $().ready(function(){
            $('#bootstrap-table').dataTable({
                initComplete: function () {
                    $('.buttons-pdf').html('<span class="fas fa-file" data-toggle="tooltip" title="Export To Pdf"/> PDF')
                    $('.buttons-print').html('<span class="fas fa-print" data-toggle="tooltip" title="Print Table"/> Print')
                    $('.buttons-copy').html('<span class="fas fa-copy" data-toggle="tooltip" title="Copy Table"/> Copy')
                    $('.buttons-excel').html('<span class="fas fa-paste" data-toggle="tooltip" title="Export to Excel"/> Excel')
                },
                "processing": true,
//                "dom": 'lBf<"top">rtip<"clear">',
                "order": [],
                "scrollX": false,
                "dom": 'lBfrtip',
                "buttons": {
                    "dom": {
                        "button": {
                            "tag": "button",
                            "className": "waves-effect waves-light btn mrm"
//                            "className": "waves-effect waves-light btn-info btn-fill btn mrm"
                        }
                    },
                    "buttons": [
                        'copyHtml5',
                        'print',
                        'excelHtml5',
//                        'csvHtml5',
                        'pdfHtml5' ]
                }
            });
        });

    </script>

    <script>

        type = ['','info','success','warning','danger'];
        demo={
            showNotification: function(from, align){
                color = Math.floor((Math.random() * 4) + 1);

                $.notify({
                    icon: "pe-7s-gift",
                    message: "<b>Light Bootstrap Dashboard PRO</b> - forget about boring dashboards."

                },{
                    type: type[color],
                    timer: 4000,
                    placement: {
                        from: from,
                        align: align
                    }
                });
            },
        }

    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>