<?php $__env->startSection('side-navbar'); ?>
	<?php echo $__env->make('layouts.side_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-navbar'); ?>
	<?php echo $__env->make('layouts.top_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
		
			
				
				
			
		
	<div class="col-md-2 col-md-offset-3">
		<?php if($errors): ?>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<input type="hidden" id="msg" > </input>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<br>
		<?php else: ?> <?php echo e($status); ?>

		<?php endif; ?>

	</div>
	<div class="content">
		<div class="container-fluid">
			<?php if($errors): ?>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<div class="row ">
						<div class="alert-danger text-center"><?php echo e($error); ?></div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<br>
			<?php endif; ?>

			<div class="row">
				<div class="col-md-8">
					<div class="card">
						<div class="header">
							<h4 class="title">Edit Profile</h4>
						</div>
						<div class="content">
							<form method="POST" action="<?php echo e(route('edit_profile')); ?>" enctype="multipart/form-data"  id="addUsr">
								<?php echo e(csrf_field()); ?>

								<div class="modal-body">
									<?php if($data['no_ktp']=="admin"): ?>
									<input type="hidden" id="no_ktp" name="admin" value="<?php echo e($data['no_ktp']); ?>">
									<div class="row">
										<div class="form-group col-md-6<?php echo e($errors->has('no_ktp') ? 'errors' : ''); ?>">
											<label for="idUsr" class="control-label">Username </label>
											<input type="text" placeholder="Nomor KTP"  class="form-control" id="idUsr" value="<?php echo e($data['no_ktp']); ?>" disabled/>
											<?php if($errors->has('no_ktp')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('no_ktp')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group col-md-6 <?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
											<label for="namaUsr" class="control-label">Nama User </label>
											<input type="text" placeholder="Nama" class="form-control" id="namaUsr" name="nama" value="<?php echo e($data['nama']); ?>" >
											<?php if($errors->has('nama')): ?>
												<span class="help-block">
                                                <strong><?php echo e($errors->first('nama')); ?></strong>
                                            </span>
											<?php endif; ?>
										</div>
									</div>
									<?php else: ?>
									<div class="row">
										<div class="form-group col-md-6<?php echo e($errors->has('no_ktp') ? 'errors' : ''); ?>">
										<label for="idUsr" class="control-label">No KTP </label>
										<input type="text" placeholder="Nomor KTP" class="form-control" id="idUsr" name="no_ktp" value="<?php echo e($data['no_ktp']); ?>"/>
										<?php if($errors->has('no_ktp')): ?>
											<span class="help-block">
											<strong><?php echo e($errors->first('no_ktp')); ?></strong>
										</span>
										<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
											<label for="namaUsr" class="control-label">Nama User </label>
											<input type="text" placeholder="Nama" class="form-control" id="namaUsr" name="nama" value="<?php echo e($data['nama']); ?>" >
											<?php if($errors->has('nama')): ?>
												<span class="help-block">
                                                <strong><?php echo e($errors->first('nama')); ?></strong>
                                            </span>
											<?php endif; ?>
										</div>
									</div>
									<?php endif; ?>

									
										
										
										
											
                                                
                                            
										
									
									<div class="row <?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
										<div class="col-md-12">
											<div class="form-group">
												<label>Alamat User</label>
												<textarea rows="5" name="alamat" class="form-control" placeholder="alamat" value=""><?php echo e($data['alamat']); ?></textarea>
												<?php if($errors->has('alamat')): ?>
													<span class="help-block">
                                                		<strong><?php echo e($errors->first('alamat')); ?></strong>
                                            		</span>
												<?php endif; ?>
											</div>
										</div>
									</div>
								</div>


								<div class="modal-footer">
									<button type="submit" class="btn btn-info btn-fill pull-rightary">Update Profile</button>
								</div>
							</form>



						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="card card-user">
						<div class="image">
							<img src="<?php echo e(URL::asset('bootstrap/assets/img/full-screen-image-3.jpg')); ?>" alt="..."/>
						</div>
						<div class="content">
							<div class="author">
								<a href="#">
									<?php if($data['no_ktp']=="admin"): ?>
										<img class="avatar border-gray" src="<?php echo e(URL::asset('bootstrap/assets/img/man.svg')); ?>" alt="..."/>
									<?php else: ?>
										<img class="avatar border-gray" src="<?php echo e(URL::asset('bootstrap/assets/img/default-avatar2.png')); ?>" alt="..."/>
									<?php endif; ?>
									<h4 class="title"><?php echo e($data['nama']); ?><br />
										<small><?php echo e($data['no_ktp']); ?></small>
									</h4>
								</a>
							</div>
							<p class="description text-center"> <?php echo e($data['alamat']); ?> <br>
							</p>
						</div>
						<hr>
						<div class="text-center">
							<div class="modal-footer">
								<button type="submit" class="btn btn-info btn-fill center-block" data-toggle="modal" data-target="#editPassUsrModal">Update Password</button>
							</div>
							
							
							
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>


	
	<div class="modal fade" id="editPassUsrModal" role="dialog" aria-labelledby="editPassUsrLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<form method="POST" action="<?php echo e(route('admin.edit_pass')); ?>" enctype="multipart/form-data"  id="passUsr">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" id="id_usr_p" name="no_ktp" value="admin">
					<div class="modal-body">
						<div class="modal-header">
							<h5 class="modal-title" id="editPassUsrlabel">Edit Password</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>

						<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
							<input type="password" placeholder="Password" class="form-control" name="password_old">
							<?php if($errors->has('password')): ?>
								<span class="help-block">
										<strong><?php echo e($errors->first('password')); ?></strong>
								</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
							<input type="password" placeholder="New Password" class="form-control" name="password">
							<?php if($errors->has('password')): ?>
								<span class="help-block">
									<strong><?php echo e($errors->first('password')); ?></strong>
								</span>
							<?php endif; ?>
						</div>

						<div class="form-group">
							<input type="password" placeholder="Password Confirmation" class="form-control" name="password_confirmation">
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
						<button type="submit" class="btn btn-danger">Ubah Password</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_script'); ?>
	<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->

	<script>


        type = ['','info','success','warning','danger'];
        demo = {
            showNotification: function(from, align,msg){
                color = Math.floor((Math.random() * 4) + 1);

                $.notify({
                    icon: "pe-7s-gift",
                    message: msg

                },{
                    type: type[color],
                    timer: 4000,
                    placement: {
                        from: from,
                        align: align
                    }
                });
            },

            showSwal: function(type){
                if(type == 'basic'){
                    swal("Here's a message!");

                }else if(type == 'title-and-text'){
                    swal("Here's a message!", "It's pretty, isn't it?")

                }else if(type == 'success-message'){
                    swal("Good job!", "You clicked the button!", "success")

                }else if(type == 'warning-message-and-confirmation'){
                    swal({  title: "Are you sure?",
                        text: "You will not be able to recover this imaginary file!",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonClass: "btn btn-info btn-fill",
                        confirmButtonText: "Yes, delete it!",
                        cancelButtonClass: "btn btn-danger btn-fill",
                        closeOnConfirm: false,
                    },function(){
                        swal("Deleted!", "Your imaginary file has been deleted.", "success");
                    });

                }else if(type == 'warning-message-and-cancel'){
                    swal({  title: "Are you sure?",
                        text: "You will not be able to recover this imaginary file!",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonText: "Yes, delete it!",
                        cancelButtonText: "No, cancel plx!",
                        closeOnConfirm: false,
                        closeOnCancel: false
                    },function(isConfirm){
                        if (isConfirm){
                            swal("Deleted!", "Your imaginary file has been deleted.", "success");
                        }else{
                            swal("Cancelled", "Your imaginary file is safe :)", "error");
                        }
                    });

                }else if(type == 'custom-html'){
                    swal({  title: 'HTML example',
                        html:
                        'You can use <b>bold text</b>, ' +
                        '<a href="http://github.com">links</a> ' +
                        'and other HTML tags'
                    });

                }else if(type == 'auto-close'){
                    swal({ title: "Auto close alert!",
                        text: "I will close in 2 seconds.",
                        timer: 2000,
                        showConfirmButton: false
                    });
                } else if(type == 'input-field'){
                    swal({
                            title: 'Input something',
                            html: '<p><input id="input-field" class="form-control">',
                            showCancelButton: true,
                            closeOnConfirm: false,
                            allowOutsideClick: false
                        },
                        function() {
                            swal({
                                html:
                                'You entered: <strong>' +
                                $('#input-field').val() +
                                '</strong>'
                            });
                        })
                }
            },
        }
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>